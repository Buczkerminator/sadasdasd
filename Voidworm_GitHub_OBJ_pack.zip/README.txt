VOIDWORM — GitHub-ready Starblast OBJ pack
===============================================

The pack contains:
- Voidworm_head.obj
- Voidworm_segment.obj
- Voidworm_reactor_segment.obj
- Voidworm_tail.obj

Orientation:
- FRONT = -Y
- REAR / chain direction = +Y
- UP = +Z

Recommended use in the worm mechanic:
var WORM_SEGMENT_OBJ_URL =
  "https://raw.githubusercontent.com/LOGIN/REPO/main/Voidworm_segment.obj";

var WORM_TAIL_OBJ_URL =
  "https://raw.githubusercontent.com/LOGIN/REPO/main/Voidworm_tail.obj";

Optional special middle segment:
  Voidworm_reactor_segment.obj

Suggested Starblast object material:
diffuseColor: 0xE7E4DA,
specularColor: 0x8A8F94,
shininess: 70,
transparent: false

The pores are real concave geometry, not a texture.
